import React, { useState, useEffect } from 'react';
import { Crown, Lock, Star, TrendingUp, Zap, Shield, Activity, X, CheckCircle, AlertCircle } from 'lucide-react';

function App() {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error' | null;
    message: string;
    show: boolean;
  }>({ type: null, message: '', show: false });
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; delay: number }>>([]);

  useEffect(() => {
    // Generate floating particles
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      delay: Math.random() * 4
    }));
    setParticles(newParticles);
  }, []);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message, show: true });
    
    // Auto hide notification after 3 seconds for error, 2 seconds for success
    setTimeout(() => {
      setNotification(prev => ({ ...prev, show: false }));
    }, type === 'error' ? 3000 : 2000);
  };

  const handleAccess = async () => {
    if (!password.trim()) {
      showNotification('error', 'Please enter a password');
      return;
    }

    setIsLoading(true);
    
    // Simulate authentication delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (password === '1234') {
      showNotification('success', 'Access Granted! Redirecting...');
      
      // Redirect to Telegram channel after 2 seconds
      setTimeout(() => {
        window.open('https://t.me/channelupdat', '_blank');
        setIsLoading(false);
        setPassword('');
      }, 2000);
    } else {
      showNotification('error', 'Access Denied! Invalid password, try again');
      setIsLoading(false);
      setPassword('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleAccess();
    }
  };

  const closeNotification = () => {
    setNotification(prev => ({ ...prev, show: false }));
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800">
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 animate-pulse"></div>
        
        {/* Floating Particles */}
        {particles.map(particle => (
          <div
            key={particle.id}
            className="absolute w-1 h-1 sm:w-2 sm:h-2 bg-yellow-400/60 rounded-full animate-float"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              animationDelay: `${particle.delay}s`,
              animationDuration: `${4 + Math.random() * 2}s`
            }}
          ></div>
        ))}

        {/* Geometric Shapes - Responsive sizes */}
        <div className="absolute top-10 left-4 sm:top-20 sm:left-20 w-16 h-16 sm:w-32 sm:h-32 bg-gradient-to-r from-yellow-400/20 to-orange-500/20 rounded-full animate-spin-slow"></div>
        <div className="absolute bottom-10 right-4 sm:bottom-20 sm:right-20 w-24 h-24 sm:w-48 sm:h-48 bg-gradient-to-r from-blue-400/20 to-purple-500/20 rounded-lg rotate-45 animate-pulse"></div>
        <div className="absolute top-1/2 left-2 sm:left-10 w-12 h-12 sm:w-24 sm:h-24 bg-gradient-to-r from-pink-400/20 to-red-500/20 rounded-full animate-bounce-slow"></div>
      </div>

      {/* Notification Sidebar */}
      <div className={`fixed top-0 left-0 right-0 z-50 transform transition-all duration-500 ease-in-out ${
        notification.show ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
      }`}>
        <div className={`mx-2 sm:mx-4 mt-2 sm:mt-4 p-3 sm:p-4 rounded-xl backdrop-blur-lg border-2 shadow-2xl ${
          notification.type === 'success' 
            ? 'bg-green-500/20 border-green-400 text-green-100' 
            : 'bg-red-500/20 border-red-400 text-red-100'
        } animate-slide-down`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              {notification.type === 'success' ? (
                <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-green-400 animate-pulse flex-shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 sm:w-6 sm:h-6 text-red-400 animate-pulse flex-shrink-0" />
              )}
              <span className="font-semibold text-sm sm:text-lg">{notification.message}</span>
            </div>
            <button
              onClick={closeNotification}
              className={`p-1 rounded-full transition-colors duration-200 flex-shrink-0 ${
                notification.type === 'success' 
                  ? 'hover:bg-green-400/20 text-green-300' 
                  : 'hover:bg-red-400/20 text-red-300'
              }`}
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-2 sm:p-4">
        <div className="w-full max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg">
          {/* Main Card */}
          <div className="backdrop-blur-lg bg-white/10 border border-yellow-400/30 rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 shadow-2xl transform hover:scale-105 transition-all duration-300">
            {/* Close Button */}
            <div className="flex justify-end mb-2 sm:mb-4">
              <button className="text-yellow-400/60 hover:text-yellow-400 transition-colors duration-200">
                <div className="w-5 h-5 sm:w-6 sm:h-6 flex items-center justify-center">×</div>
              </button>
            </div>

            {/* Header */}
            <div className="text-center mb-4 sm:mb-6 md:mb-8">
              <div className="flex items-center justify-center gap-1 sm:gap-2 mb-1 sm:mb-2">
                <Crown className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-yellow-400 animate-bounce" />
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                  Y.Q.T BOT PRO
                </h1>
                <Crown className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-yellow-400 animate-bounce" style={{ animationDelay: '0.2s' }} />
              </div>
              <p className="text-blue-200/80 text-xs sm:text-sm">
                <Shield className="w-3 h-3 sm:w-4 sm:h-4 inline mr-1" />
                Premium Trading Bot Authentication
              </p>
            </div>

            {/* Bot Logo */}
            <div className="flex justify-center mb-4 sm:mb-6">
              <div className="relative">
                <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-pulse-glow">
                  <div className="w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 bg-gray-900 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 sm:w-8 sm:h-8 md:w-10 md:h-10 text-yellow-400 animate-pulse" />
                  </div>
                </div>
                <div className="absolute -top-1 -right-1 sm:-top-2 sm:-right-2 w-6 h-6 sm:w-8 sm:h-8 bg-yellow-400 rounded-full flex items-center justify-center animate-bounce">
                  <Zap className="w-3 h-3 sm:w-4 sm:h-4 text-gray-900" />
                </div>
              </div>
            </div>

            {/* Lock Section */}
            <div className="text-center mb-4 sm:mb-6">
              <Lock className="w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 text-yellow-400/80 mx-auto mb-3 sm:mb-4 animate-pulse" />
              <div className="flex items-center justify-center gap-1 sm:gap-2 mb-1 sm:mb-2">
                <Star className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400 animate-spin-slow" />
                <p className="text-yellow-200 text-xs sm:text-sm px-2">Enter password to access the premium bot</p>
                <Star className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400 animate-spin-slow" style={{ animationDelay: '1s' }} />
              </div>
            </div>

            {/* Password Input */}
            <div className="mb-4 sm:mb-6">
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="🔑 Enter password..."
                  className="w-full px-3 py-2 sm:px-4 sm:py-3 text-sm sm:text-base bg-gray-900/80 border border-yellow-400/30 rounded-lg sm:rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-yellow-400 focus:ring-2 focus:ring-yellow-400/20 transition-all duration-300"
                  disabled={isLoading}
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/5 to-transparent rounded-lg sm:rounded-xl opacity-0 hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
              </div>
            </div>

            {/* Access Button */}
            <button
              onClick={handleAccess}
              disabled={isLoading}
              className="w-full py-3 sm:py-4 text-sm sm:text-base bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold rounded-lg sm:rounded-xl transform hover:scale-105 active:scale-95 transition-all duration-200 disabled:opacity-50 disabled:transform-none shadow-lg hover:shadow-red-500/25"
            >
              <div className="flex items-center justify-center gap-1 sm:gap-2">
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 sm:w-5 sm:h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>AUTHENTICATING...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5" />
                    <span>ACCESS PREMIUM BOT</span>
                    <Crown className="w-4 h-4 sm:w-5 sm:h-5" />
                  </>
                )}
              </div>
            </button>

            {/* Footer */}
            <div className="mt-4 sm:mt-6 md:mt-8 text-center">
              <div className="flex items-center justify-center gap-1 sm:gap-2 mb-2 sm:mb-3">
                <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400 animate-pulse" />
                <p className="text-yellow-400 font-semibold text-sm sm:text-base">Made by Yousaf Trader</p>
                <Crown className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400 animate-pulse" style={{ animationDelay: '0.5s' }} />
              </div>
              
              <div className="flex flex-wrap justify-center gap-2 sm:gap-4 text-xs text-blue-200/80">
                <div className="flex items-center gap-1">
                  <Shield className="w-3 h-3 text-green-400" />
                  <span>Premium Trading Signals</span>
                </div>
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-3 h-3 text-blue-400" />
                  <span>High Accuracy</span>
                </div>
                <div className="flex items-center gap-1">
                  <Activity className="w-3 h-3 text-purple-400" />
                  <span>Real-time Analysis</span>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Features */}
          <div className="mt-4 sm:mt-6 grid grid-cols-3 gap-2 sm:gap-4">
            <div className="backdrop-blur-lg bg-white/5 border border-green-400/30 rounded-lg sm:rounded-xl p-2 sm:p-4 text-center hover:bg-white/10 transition-all duration-300">
              <TrendingUp className="w-4 h-4 sm:w-6 sm:h-6 text-green-400 mx-auto mb-1 sm:mb-2 animate-pulse" />
              <p className="text-green-200 text-xs font-medium">97% Accuracy</p>
            </div>
            <div className="backdrop-blur-lg bg-white/5 border border-blue-400/30 rounded-lg sm:rounded-xl p-2 sm:p-4 text-center hover:bg-white/10 transition-all duration-300">
              <Zap className="w-4 h-4 sm:w-6 sm:h-6 text-blue-400 mx-auto mb-1 sm:mb-2 animate-pulse" />
              <p className="text-blue-200 text-xs font-medium">Lightning Fast</p>
            </div>
            <div className="backdrop-blur-lg bg-white/5 border border-purple-400/30 rounded-lg sm:rounded-xl p-2 sm:p-4 text-center hover:bg-white/10 transition-all duration-300">
              <Shield className="w-4 h-4 sm:w-6 sm:h-6 text-purple-400 mx-auto mb-1 sm:mb-2 animate-pulse" />
              <p className="text-purple-200 text-xs font-medium">Secure</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;